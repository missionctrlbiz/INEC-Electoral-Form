  

<!-- This closes the main container from the header --> 
<footer class="bg-white border-t border-slate-200"> 
    <div class="container mx-auto px-6 py-6"> 
        <p class="text-center text-slate-500 text-sm">&copy; 2025 Electoral Commission. All Rights Reserved.</p> 
    </div>     
</footer>  
